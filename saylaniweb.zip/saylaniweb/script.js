const menu = [
    { name: "Sandwich", img: "sandwich.jpg", price: 8.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "lunch" },
    { name: "Salad", img: "salad.jpg", price: 7.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "lunch" },
    { name: "Soup", img: "soup.jpg", price: 6.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "lunch" },
    { name: "Steak", img: "steak.jpg", price: 15.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "dinner" },
    { name: "Pasta", img: "pasta.jpg", price: 12.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "dinner" },
    { name: "Fish", img: "fish.jpg", price: 14.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "dinner" },
    { name: "Pancakes", img: "pancakes.jpg", price: 9.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "breakfast" },
    { name: "Omelette", img: "omelette.jpg", price: 8.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "breakfast" },
    { name: "Toast", img: "toast.jpg", price: 5.99, description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", category: "breakfast" }
  ];
  
  // Get references to the buttons and menu container
  const allBtn = document.getElementById("all-btn");
  const lunchBtn = document.getElementById("lunch-btn");
  const dinnerBtn = document.getElementById("dinner-btn");
  const breakfastBtn = document.getElementById("breakfast-btn");
  const menuContainer = document.getElementById("menu-container");
  
  // Function to display menu items based on category
  function displayMenu(category) {
    const filteredMenu = category === 'all' ? menu : menu.filter(item => item.category === category);
    menuContainer.innerHTML = '';
    filteredMenu.forEach(item => {
      const menuItem = document.createElement('div');
      menuItem.classList.add('menu-item');
      menuItem.innerHTML = `
        <img src="${item.img}" alt="${item.name}">
        <h3>${item.name}</h3>
        <p>$${item.price}</p>
        <p>${item.description}</p>
      `;
      menuContainer.appendChild(menuItem);
    });
  }
  
  // Event listeners for buttons
  allBtn.addEventListener("click", () => displayMenu("all"));
  lunchBtn.addEventListener("click", () => displayMenu("lunch"));
  dinnerBtn.addEventListener("click", () => displayMenu("dinner"));
  breakfastBtn.addEventListener("click", () => displayMenu("breakfast"));
  
  // Initial display
  displayMenu("all");
